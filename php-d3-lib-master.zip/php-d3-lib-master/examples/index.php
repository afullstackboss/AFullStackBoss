<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <title>php-d3-lib examples</title>
    <script type="text/javascript" src="js/d3.v4.min.js"></script>

</head>
<body>
<?php include_once('menu.php'); ?>
</body>
</html>
